/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

/**
 *
 * @author MushyFiq
 */
//import java.util.Date;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JTextArea;
//import java.time.Month;

public class Person {

    //Date DOB=new Date();
   // static DateFormat Dateformatter=new SimpleDateFormat("dd-MM-yyyy");
    private String FirstName = "";
    private String SurName = "";
    private IAddress HomeAddress;
    private String DOB = "01-01-1900";
    private String CustomerSince; 
    private ArrayList<Account> Accounts=null;

    /*DateTimeFormatter formatters=DateTimeFormatter.ofPattern("dd/mm/uuuu");
    String formattedDate=DOB.format(formatters);*/

    //System.out.println(DOB);
    public void AddAccount(Account src){
        Accounts.add(src);
    }
    public void DisplayAddress(JTextArea src) {

        // HomeAddress.Move("","Dellow Close","",99,"","IG2 7ED","Ilford","United Kingdom");
        HomeAddress.Display(src);
    }

    public void DisplayDetails(JTextArea src) {

        src.append("Full Name:  " + FirstName + " " + SurName + "\n"
                + "Date of Birth: " + DOB+ "\n"+"Customer Since: "+CustomerSince+"\n"+"\n"
        );
       // src.append(HomeAddress.Display(src));

    }
    public void DisplayAccounts(JTextArea src){
        this.DisplayDetails(src);
        
        if(Accounts.size()==0){
            src.append("There are no accounts to display.");
        }
        for(int i=0;i<Accounts.size();i++){
            Accounts.get(i).Display(src);
        }
    }

    public void checkDOB(LocalDate DOB) {

    }

    public void Edit(String fname, String sname, String dob) {

        FirstName = fname;
        SurName = sname;
        DOB = dob;

    }
    public void EditDetails(String fname,String sname,String dob,String custSince,String strname, String strstreet, String strhouse_name, int intHouseNo, String strarea, String strpostcode,
            String strtown, String strcountry){
        FirstName=fname;
        SurName=sname;
        DOB=dob;
        CustomerSince=custSince;
        HomeAddress.Move(strname, strstreet, strhouse_name, intHouseNo, strarea, strpostcode, strtown, strcountry);
        
    }
    public String getSurName(){
        return SurName;
    }
    public String getFirstName(){
        return FirstName;
    }

    public void SaveToFile(FileWriter writer) {

       try{
        //writer=new FileWriter("Clients.txt",true);
        writer.write(
                FirstName+"\n"+
                        SurName+"\n"+
                        DOB+"\n"+
                        CustomerSince+"\n");
        HomeAddress.SaveToFile(writer);
        
        writer.flush();
        writer.close();
        
        
        
        
       
       }
       catch (IOException ioe){}

        
    }    

    public void LoadFromFile(BufferedReader bin) {
        try{
            bin.readLine();
            this.EditDetails(bin.readLine(), bin.readLine(), bin.readLine(), bin.readLine(), bin.readLine(), bin.readLine(),
                    bin.readLine(), Integer.valueOf(bin.readLine()), bin.readLine(), bin.readLine(), bin.readLine(), bin.readLine());
        }
        catch (IOException ioe){}

    }

    public Person() {

        HomeAddress = new IAddress();
        /*IAddress(String strname, String strstreet, String strhouse_name, int intHouseNo, String strarea, String strpostcode,
            String strtown, String strcountry)*/
        Accounts=new ArrayList();

    }
    public void CreateAccount(Account a){
        Accounts.add(a);
        a.SetCustomer(this);
    }
    public boolean Compare(Person aPerson){
        if (FirstName.equals(aPerson.FirstName)&& SurName.equals(aPerson.SurName)&& DOB.equals(aPerson.DOB) &&
        HomeAddress.Compare(aPerson.HomeAddress) && CustomerSince.equals(aPerson.CustomerSince)){
            
            return true;
        }
        else return false;
    }
    public Person(String Fname,String Sname,IAddress homeaddress,String dob,String custSince){
        FirstName=Fname;
        SurName=Sname;
        HomeAddress=homeaddress;
        DOB=dob;
        CustomerSince=custSince;
    }

}
