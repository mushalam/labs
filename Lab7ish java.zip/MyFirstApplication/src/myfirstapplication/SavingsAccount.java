/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.util.Date;
import javax.swing.JTextArea;

/**
 *
 * @author MushyFiq
 */
public class SavingsAccount extends Account {
    private double WithdrawLimit;
    
    
    public SavingsAccount(Person cust){
        super(cust);
        
        
    }
    public SavingsAccount(Person cust,String bankname,String accno,String sortcode,Date d){
       super(cust,bankname,accno,sortcode,d);
        
        
    }
   @Override
    public void Display(JTextArea src){
       src.append("Account Type: Savings Account \n");
       super.Display(src);
    }

  public void Withdraw(double Amount){
      
  } 

    @Override
    public void Deposit(double amount) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void EndOfMonth(Date transactionDate, JTextArea src) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
