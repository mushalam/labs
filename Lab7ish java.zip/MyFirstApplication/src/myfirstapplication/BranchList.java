/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JTextArea;

/**
 *
 * @author MushyFiq
 */
public class BranchList {
    ArrayList <Branch> Branches=new ArrayList();
    private BranchList SubDepartments;
    
    public BranchList(){
        //this.LoadFromFile();
        SubDepartments=null;
    }
    
    public void Add(Branch NewBranch){
        Branches.add(NewBranch);
        
    }
    public void AddSubDepartments(){
        if(SubDepartments==null){
            SubDepartments=new BranchList();
        }
    }
    public void AddDepartment(Branch b){
        SubDepartments.Add(b);
    }
    public BranchList GetSubDepartments(){
        return SubDepartments;
    }
    public void Remove(Branch src){
        Branches.remove(src);
    }
    public void RemoveBySortCode(String sortcode){
        while(RemoveCondition(sortcode));
    }

    public boolean RemoveCondition(String sortcode) {
        boolean isRemoved=false;
        for (int i = 0; i < Branches.size(); i++) {
            if (Branches.get(i).getSortCode().equals(sortcode)) {
                Branches.remove(i);
                isRemoved=true;

            }
        }
        return isRemoved;
    }
    public void SaveToFile(){
        FileWriter writer;
        
        try{
           writer=new FileWriter("Branches.txt");
           writer.write(Branches.size()+"\n"+"\n");
           
           for (int i=0;i<Branches.size();i++){
               Branches.get(i).SaveToFile(writer);
           }
           writer.flush();
           writer.close();
        }
        catch (IOException ioe){}
    }
    public void SaveToFile(String file){
        FileWriter writer;
        
        try{
           writer=new FileWriter(file);
           writer.write(Branches.size()+"\n"+"\n");
           
           for (int i=0;i<Branches.size();i++){
               Branches.get(i).SaveToFile(writer);
           }
           writer.flush();
           writer.close();
        }
        catch (IOException ioe){}
    }
    public void LoadFromFile(){
        FileReader reader;
        BufferedReader bin;
        Branches.removeAll(Branches);
        
        try{
            reader=new FileReader("Branches.txt");
            bin=new BufferedReader(reader);
            int size=Integer.valueOf(bin.readLine());
            for(int i=0;i<size;i++){
                Branches.add(new Branch());
                Branches.get(i).LoadFromFile(bin);
            }
            reader.close();
        }
        catch (IOException ioe){}
    }
    public void LoadFromFile(String file){
        FileReader reader;
        BufferedReader bin;
        Branches.removeAll(Branches);
        
        try{
            reader=new FileReader(file);
            bin=new BufferedReader(reader);
            int size=Integer.valueOf(bin.readLine());
            for(int i=0;i<size;i++){
                Branches.add(new Branch());
                Branches.get(i).LoadFromFile(bin);
            }
            reader.close();
        }
        catch (IOException ioe){}
    }
     public void Display(JTextArea src) {
        src.setText("");
        for (int i = 0; i < Branches.size(); i++) {
            Branches.get(i).DisplayBranch(src);
            Branches.get(i).Display(src);

        }
    }
    
    
}
