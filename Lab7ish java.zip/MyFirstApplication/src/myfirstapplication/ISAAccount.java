/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 *
 * @author MushyFiq
 */
public class ISAAccount extends Account{
    private double AllowancePerYear;
    private double DepositForYear;
 
    public ISAAccount(Person cust){
        super (cust);
        AllowancePerYear=3250;
        DepositForYear=0;
    }
    public ISAAccount(Person cust,String bankname,String accno,String sortcode,Date startdate){
        super(cust,bankname,accno,sortcode,startdate);
    }

    @Override
    public void Display(JTextArea src){
       src.append("Account Type: ISA Account \n");
       super.Display(src);
    }
    public void Withdraw(double amount) {
    if (amount > Balance) {
        JOptionPane.showMessageDialog(null,"you do not have sufficient balance.");
        } else {
            Balance = Balance - amount;
            Transactions++;
        }
    }

    @Override
    public void Deposit(double amount) {
         if(amount+DepositForYear>AllowancePerYear){
             JOptionPane.showMessageDialog(null, "Warning! You have exceeded the allowance for this year. Deposit failed.");
         }
         else{
             Balance=Balance+amount;
             DepositForYear=DepositForYear+amount;
             Transactions++;
         }
    }

    @Override
    public void EndOfMonth(Date transactionDate, JTextArea src) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
