/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.util.Date;
import javax.swing.JTextArea;

/**
 *
 * @author MushyFiq
 */
public class CurrentAccount extends Account{
    
    private double OverDraft;
    //Person cust,String bankname,String accno,String sortcode
    public CurrentAccount(Person cust){
        super(cust);
        OverDraft=100;
        
    }
    public CurrentAccount(Person cust,String bankname,String accno,String sortcode,Date d){
        super(cust,bankname,accno,sortcode,d);
        OverDraft=100;
        
    }
    @Override
    public void Display(JTextArea src){
       src.append("Account Type: Current Account \n");
       super.Display(src);
    }
    public void Withdraw(double amount){
        if(amount>Balance+OverDraft){
            Balance=Balance-amount-25;
            Transactions++;
        }
        else{
            Balance=Balance-amount;
        }
    }

    @Override
    public void Deposit(double amount) {
        Balance=Balance+amount;
        Transactions++;
    }

    @Override
    public void EndOfMonth(Date transactionDate, JTextArea src) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
