/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

/**
 *
 * @author MushyFiq
 */


//import java.awt.TextArea;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import javax.swing.JTextArea;

public class Branch {
    private IAddress mailingAddress;
    private String workingHours="9:00-17:00";
    private String sortCode="00-00-00";
    private Person manager;
    //private JTextArea jOutputTextArea;
    
    
    
    public Branch(){
        
        //have to write down the address for the headoffice to initialise
        
        manager=new Person();
       mailingAddress=new IAddress("TSB Bank","Chequers Square","The Pavilions",24,"","UB8 1LN","Uxbridge","United Kingdom");
       //24 Chequers Square, Uxbridge UB8 1LN
       /*IAddress(String strname, String strstreet, String strhouse_name, int intHouseNo, String strarea, String strpostcode,
            String strtown, String strcountry)*/
        this.LoadFromFile();
    }
    public String getSortCode(){
        return sortCode;
    }
    public void Display(JTextArea src){
        
        
        mailingAddress.Display(src);
        
        
    }
    public void DisplayBranch(JTextArea src){
        src.append(
                
                "Working Hours: "+workingHours+"\n"
                +"Sort Code: "   +sortCode+"\n"
        
        );
    }
       public void DisplayDetails(JTextArea src){
        
        
        manager.DisplayDetails(src);
       }
       public void DisplayAddress (JTextArea src){
        
       // HomeAddress.Move("","Dellow Close","",99,"","IG2 7ED","Ilford","United Kingdom");
        manager.DisplayAddress(src);
    }
    public void Edit(String strname, String strstreet, String strhouse_name, int intHouseNo, String strarea, String strpostcode,
            String strtown, String strcountry){
        
        mailingAddress.Move(strname, strstreet, strhouse_name, intHouseNo, strarea, strpostcode, strtown, strcountry);
    }
    public void EditBranch(String hours,String sort_code){
        
        workingHours=hours;
        sortCode=sort_code;
    }
    public void EditBranchDetails(String hours,String sort_code,String strname, String strstreet, String strhouse_name, int intHouseNo, String strarea, String strpostcode,
            String strtown, String strcountry){
        
        mailingAddress.Move(strname, strstreet, strhouse_name, intHouseNo, strarea, strpostcode, strtown, strcountry);
    }
    
    public void isHeadOffice(){
        
    }
    public void EditPersonDetails(String fname,String sname,String dob){
        
        manager.Edit(fname, sname, dob);
        
    }
    public void SaveToFile(FileWriter writer) {
        try {

            writer.write(
                    workingHours+"\n"+sortCode+"\n");
            mailingAddress.SaveToFile(writer);

            writer.flush();
        } catch (IOException ioe) {
        }

    }
    public void LoadFromFile(BufferedReader buf) {
        try{
            buf.readLine();
        
            
         this.EditBranch(buf.readLine(), buf.readLine());
         this.Edit(buf.readLine(), buf.readLine(), buf.readLine(), Integer.valueOf(buf.readLine()), buf.readLine(),
                 buf.readLine(), buf.readLine(), buf.readLine());
        }
        catch (IOException ioe){}

    }
    public void SaveToFile(){
        
        FileWriter Writer;
        
        try{
            Writer=new FileWriter("save.txt",true);
            Writer.write(workingHours+"\n"+sortCode+"\n");
            mailingAddress.SaveToFile();
            
            Writer.flush();
            Writer.close();
            
        }
        catch (IOException ioe) {
           
        }
        
    }
    
    public void LoadFromFile(){
        FileReader Reader;
        try{
         Reader=new FileReader("save.txt");
         BufferedReader buf=new BufferedReader(Reader);
         
         //this.EditBranch(buf.readLine(), buf.readLine());
         this.Edit(buf.readLine(), buf.readLine(), buf.readLine(), Integer.valueOf(buf.readLine()), buf.readLine(),
                 buf.readLine(), buf.readLine(), buf.readLine());
         this.EditBranch(buf.readLine(), buf.readLine());
         
        }catch(IOException ioe) {

        }
        
    }

    
    
}
