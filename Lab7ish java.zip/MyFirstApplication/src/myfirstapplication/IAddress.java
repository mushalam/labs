/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

/**
 *
 * @author MushyFiq
 */
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JTextArea;

public class IAddress {

    private String Name = "";
    private String Street = "";
    private int HouseNo = 0;
    private String HouseName = "";
    private String Area = "";
    private String PostCode = "";
    private String Town = "";
    private String Country = "";
    //private Branch Hours;

    public IAddress(String strname, String strstreet, String strhouse_name, int intHouseNo, String strarea, String strpostcode,
            String strtown, String strcountry) {
        Move(strname, strstreet, strhouse_name, intHouseNo, strarea, strpostcode, strtown, strcountry);
        //Hours=new Branch();
    }

    public IAddress() {

        Move("", "", "", 0, "", "", "", "");
    }

    public boolean Compare(IAddress src){
        if(Name.equals(src.Name) && Street.equals(src.Street) && HouseName.equals(src.HouseName) &&
                (HouseNo==src.HouseNo) && Area.equals(src.Area) && PostCode.equals(src.PostCode) &&
                Town.equals(src.Town) && Country.equals(src.Country)){
            return true;
        }
        else return false;
        
    }

    public void Display(JTextArea src) {
        //System.out.println(Name+", "+HouseName+", "+HouseNo+", "+Street+", "+Area+", "+Town+", "+PostCode+", "+Country+".");
        src.append(
                "Name: " + Name + "\n"
                + "House Name: " + HouseName + "\n"
                + "House Number: " + HouseNo + "\n"
                + "Street: " + Street + "\n"
                + "Area: " + Area + "\n"
                + "Town:" + Town + "\n"
                + "Post Code: " + PostCode + "\n"
                + "Country: " + Country + "\n" + "\n"
        /*+"Branch Details :" + "\n"
                +"Working Hours: "  +Hours.workingHours+"\n"*/
        );

    }

    public void Move(String strname, String strstreet, String strhouse_name, int intHouseNo, String strarea, String strpostcode,
            String strtown, String strcountry) {

        Name = strname;
        HouseName = strhouse_name;
        HouseNo = intHouseNo;
        Street = strstreet;
        Area = strarea;
        Town = strtown;
        PostCode = strpostcode;
        Country = strcountry;

    }

    public void SaveToFile() {

        FileWriter Writer;

        try {
            Writer = new FileWriter("save.txt", false);
            Writer.write(
                    Name + "\n"
                    + Street + "\n"
                    + HouseName + "\n"
                    + HouseNo + "\n"
                    + Area + "\n"
                    + PostCode + "\n"
                    + Town + "\n"
                    + Country + "\n"
            );
            Writer.flush();

        } catch (IOException ioe) {

        }
    }
    public void SaveToFile(FileWriter Writer) {

        //FileWriter Writer;

        try {
            //Writer = new FileWriter("save.txt", false);
            Writer.write(
                    Name + "\n"
                    + Street + "\n"
                    + HouseName + "\n"
                    + HouseNo + "\n"
                    + Area + "\n"
                    + PostCode + "\n"
                    + Town + "\n"
                    + Country + "\n"+"\n"
            );
            Writer.flush();

        } catch (IOException ioe) {

        }
    }

    public void LoadFromFile() {

    }

}
