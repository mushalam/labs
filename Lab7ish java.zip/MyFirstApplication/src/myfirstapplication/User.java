/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author MushyFiq
 */
public class User {

    private String name = "";
    private String role = "";
    private String password = "";
    private String filename = "login.txt";

    public void SaveToFile() {

    }

    public void LoadFromFile() {

    }

    public User() {

    }

    public boolean isManager() {

        return true;
    }

    public boolean isUser(String newName, String newPassword, String newRole) {
        name = newName;
        password = newPassword;
        role = newRole;
        boolean isFound = false;
        String record;
        FileReader reader;

        try {
            reader = new FileReader(filename);
            BufferedReader bin = new BufferedReader(reader);
            record = new String();
            //record1=new String();
            while ((record = bin.readLine()) != null) {
                if (name.contentEquals(record)) {
                    //isFound=true;

                    while (!"##".equals(record = bin.readLine())) {

                        if (password.contentEquals(record)) {
                            //while (!"##".equals(record = bin.readLine())) {
                            record = bin.readLine();
                            if (role.contentEquals(record)) {

                                isFound = true;
                            }

                            //isFound=true;
                            //}
                        }
                    }

                }

            }
            bin.close();
            bin = null;
        } catch (IOException ioe) {
            isFound = false;
        }
        return isFound;
    }

    public boolean isUser2(String newName, String newPassword, String newRole) {
        name = newName;
        password = newPassword;
        role = newRole;
        boolean isFound = false;
        String namePass=name+' '+password+' '+role;
        String record;
        FileReader reader;

        try {
            reader = new FileReader(filename);
            BufferedReader bin = new BufferedReader(reader);
            record = new String();
            //record1=new String();
         while ((record = bin.readLine()) != null) {
                if (namePass.contentEquals(record)) {
                    isFound=true;
                }
                

            }
            bin.close();
            bin = null;
        } catch (IOException ioe) {
            isFound = false;
        }
        return isFound;
    }

    public boolean isRole(String newName, String newPassword, String newRole) {
        name = newName;
        password = newPassword;
        role = newRole;
        boolean isFound = false;
        String record;
        FileReader reader;

        try {
            reader = new FileReader(filename);
            BufferedReader bin = new BufferedReader(reader);
            record = new String();
            while ((record = bin.readLine()) != null) {
                if (name.contentEquals(record)) {
                    while (!"##".equals(record = bin.readLine())) {

                        if (role.contentEquals(record)) {
                            isFound = true;
                        }
                    }

                }

            }
            bin.close();
            bin = null;
        } catch (IOException ioe) {
            isFound = false;
        }
        return isFound;
    }

    public boolean isRegistered(String newName, String newPassword, String newRole) {
        boolean isRegistered;
        name = newName;
        password = newPassword;
        role = newRole;

        FileWriter writer;

        try {
            writer = new FileWriter(filename, true);
            writer.write(name + " " + password
                    + " " + role + "\n" + "## \n");
            
            isRegistered = true;
            writer.flush();
            writer.close();
            writer = null;
        } catch (IOException ioe) {
            isRegistered = false;
        }

        return isRegistered;
    }

}
