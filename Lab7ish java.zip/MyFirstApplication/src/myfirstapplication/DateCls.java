/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

/**
 *
 * @author MushyFiq
 */
public class DateCls {
    private int Day;
    private int Month;
    private int Year;
    
    public DateCls(){
        this.Edit(1,1,1900);
    }
    public DateCls(int day, int month, int year){
        this.Edit(day,month,year);
    }
    public void Edit(int day,int month,int year){
        Day=day;
        Month=month;
        Year=year;
        
    }
    public String GetDateOf(int day,int month,int year){
        return (Integer.toString(day)+"/"+Integer.toString(month)+"/"+Integer.toString(year));
    }
    public String Get(){
        return (Integer.toString(Day)+"/"+Integer.toString(Month)+"/"+Integer.toString(Year));
    }
    
}
