/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import javax.swing.JTextArea;

/**
 *
 * @author MushyFiq
 */
public abstract class Account {
    protected String SortCode;
    protected String AccountNo;
    protected double Balance;
    protected String BankName;
    protected double Rate;
    protected Person AccountHolder=null;
    protected int Transactions;
    protected Date AccountStartDate;
   
    private Date LastReportedDate;
    
    public Account(Person cust){
        Date d=new Date(1/1/1900);
        //DateCls d=new DateCls(1,1,1900);
        this.Edit("", "", 0, "", 0, d,0,d);
        //AccountHolder=new Person();
        AccountHolder=cust;
        
    }
    public Account(Person cust,String bankname,String accno,String sortcode,Date startdate){
        Date d=new Date(1/1/1900);
        //DateCls d=new DateCls(1,1,1900);
        this.Edit(sortcode, accno, 0, bankname, 0, d,0,d);
        //AccountHolder=new Person();
        AccountHolder=cust;
        
    }
    public void Edit(String scode,String AccNo,double balance,String bankname,double rate,Date lastrepdate,int transactions,Date startdate){
        SortCode=scode;
        AccountNo=AccNo;
        BankName=bankname;
        Balance=balance;
        Rate=rate;
        LastReportedDate=lastrepdate;
        
    }
    public void Create(){
        
    }
    public void Display(JTextArea src){
        src.append("Bank Name: "+BankName+"\n"
        +"Account Number: "+AccountNo+"\n"
        +"Sort Code: "+SortCode+"\n"
        +"Balance :"+Balance+"\n"+"\n");
    }
    public abstract void Deposit(double amount);
    public abstract void Withdraw(double amount);
    public void Transfer(Account recipient){
        
    }
    public void Save(){
        
    }
    public void Load(){
        
    }
    public void CalculateCharges(){
        Balance = Balance + (Balance * Rate);
    }
    public void PrintStatement(){
       
    }
    public abstract void EndOfMonth(Date transactionDate, JTextArea src);
    public double GetBalance(){
        return Balance;
    }
    public void SetCustomer(Person src){
        
        AccountHolder=src;
    }
    protected void EndOfMonthTransactions(JTextArea jAccountTextArea) {
        jAccountTextArea.append("Transactions:" + Transactions + "\t Balance: " + Balance + "\t(" + this + ")");
        Transactions = 0;
    }
  
}
