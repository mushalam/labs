/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JTextArea;

/**
 *
 * @author MushyFiq
 */
public class ClientList {

    private ArrayList<Person> Clients = null;

    public void Add(Person NewPerson) {
       if((Clients!=null)&&(NewPerson!=null)){ Clients.add(NewPerson);}
    }

    public void Remove(Person src) {
        Clients.remove(src);

    }
    public void Find(Person aClient,JTextArea src){
        //Person theClient=new Person();
        boolean found =false;
        for (int i=0;i <Clients.size() ; i++){
            if(Clients.get(i).Compare(aClient)){
                src.setText("");
                Clients.get(i).DisplayAddress(src);
                found=true;
            }
            
        }
        if(!found){
            src.setText("Client not found.");
        }
        
        //return theClient;
    }

    public void Display(JTextArea src) {
        src.setText("");
        for (int i = 0; i < Clients.size(); i++) {
            Clients.get(i).DisplayDetails(src);
            Clients.get(i).DisplayAddress(src);

        }
    }

    public ClientList() {
     if (Clients == null)
          Clients = new ArrayList();
     //this.LoadFromFile();
    }
    public void RemoveByName(String fname,String sname){
        while(RemoveCondition(fname,sname));
    }

    public boolean RemoveCondition(String fname, String sname) {
        boolean isRemoved=false;
        for (int i = 0; i < Clients.size(); i++) {
            if (Clients.get(i).getSurName().equals(sname) && Clients.get(i).getFirstName().equals(fname)) {
                Clients.remove(i);
                isRemoved=true;

            }
        }
        return isRemoved;
    }
    public Person FindByName(String fname,String sname){
        Person aClient=new Person();
        for (int i = 0; i < Clients.size(); i++) {
            if (Clients.get(i).getSurName().equals(sname) && Clients.get(i).getFirstName().equals(fname)) {
                
                aClient=Clients.get(i);
                

            }
            //return aClient;
    }return aClient;
    }

    public void Edit(String Sname, String Fname, String aFname, String aSname, String aDOB, String aCustSince, String aName, String aHouseName, int aHouseNo,
            String aStreet, String aArea, String aPostCode, String aTown,
            String aCountry) {
        for (int i = 0; i < Clients.size(); i++) {
            if (Clients.get(i).getSurName().equals(Sname) && Clients.get(i).getFirstName().equals(Fname)) {
                Clients.get(i).EditDetails(aFname, aSname, aDOB, aCustSince, aName, aStreet, aHouseName, aHouseNo, aArea, aPostCode,
                        aTown, aCountry);
            }
        }

    }
    public void SaveToFile(){
        FileWriter writer;
        
        try{
           writer=new FileWriter("Clients.txt");
           writer.write(Clients.size()+"\n"+"\n");
           
           for (int i=0;i<Clients.size();i++){
               Clients.get(i).SaveToFile(writer);
           }
           writer.flush();
           writer.close();
        }
        catch (IOException ioe){}
    }
    public void LoadFromFile(){
        FileReader reader;
        BufferedReader bin;
        Clients.removeAll(Clients);
        
        try{
            reader=new FileReader("Clients.txt");
            bin=new BufferedReader(reader);
            int size=Integer.valueOf(bin.readLine());
            for(int i=0;i<size;i++){
                Clients.add(new Person());
                Clients.get(i).LoadFromFile(bin);
            }
            reader.close();
        }
        catch (IOException ioe){}
    }

}
