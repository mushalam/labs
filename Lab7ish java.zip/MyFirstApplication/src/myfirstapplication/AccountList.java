/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.util.ArrayList;

/**
 *
 * @author MushyFiq
 */
public class AccountList {
    private ArrayList<Account> Accounts=null;
    
    public AccountList(){
        
    }
    
    
    
}
