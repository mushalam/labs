/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author MushyFiq
 */
public class Customer {
    static DateFormat Dateformatter=new SimpleDateFormat("dd-MM-yyyy");
    private String FirstName;
    private String SurName;
    private IAddress HomeAddress;
    private String DOB="01-01-1900";
    private String CustomerSince;
    
    public void Display(){
        
        
    }
    public void CheckDOB(){
        
        
    }
    
    
    
    //DOB.
    
    
}
